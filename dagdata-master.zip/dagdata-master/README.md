# Data package for the PH525x series

* Instructors: try to avoid adding objects larger than 5 Mb. Large
  data objects can go in their own package (own repo). 
* `.RData` or `.rda` files go in `data/`.
* Other files, `csv`, etc., go in `inst/extdata/`.

